export interface OrderItem {
  menuItemId: string;
  name: string;
  price: number;
  quantity: number;
}

export interface CustomerOrder {
  id: string;

  diningSessionId: string;

  items: OrderItem[];

  totalPrice: number;

  status: string;

  createdAt: string;

  updatedAt?: string;

  specialInstructions?: string;
}

export interface CreateOrderRequest {
  diningSessionId: string;

  items: OrderItem[];

  specialInstructions?: string;
}
