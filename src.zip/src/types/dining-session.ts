export type SessionSource = "QUEUE" | "WALK_IN" | "RESERVATION";

export type SessionStatus = "ACTIVE" | "BILLING" | "COMPLETED";

export interface DiningSession {
  id: string;

  restaurantId: string;

  tableId: string;

  queueId: string | null;

  sessionToken: string;

  joinCode: string;

  createdByName: string;

  createdByPhone: string;

  status: SessionStatus;

  source: SessionSource;

  partySize: number;

  startedAt: string;

  endedAt: string | null;

  createdAt: string;

  updatedAt: string;
}
