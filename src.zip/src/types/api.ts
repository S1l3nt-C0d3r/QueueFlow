export interface ApiError {
  message: string;
}

export interface PaginatedResponse<T> {
  items: T[];

  total: number;

  page: number;

  pageSize: number;
}