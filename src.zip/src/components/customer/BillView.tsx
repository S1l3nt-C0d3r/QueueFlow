import { motion } from "motion/react";
import { Receipt, Clock3, CheckCircle2, CreditCard } from "lucide-react";

export type BillStatus = "not_requested" | "requested" | "ready" | "paid";

export interface BillItem {
  id: string;
  name: string;
  quantity: number;
  price: number;
}

export interface BillViewProps {
  status?: BillStatus;
  items?: BillItem[];
  subtotal?: number;
  tax?: number;
  total?: number;
  onRequestBill?: () => void;
  onPayBill?: () => void;
  isRequesting?: boolean;
  isPaying?: boolean;
}

export default function BillView({
  status = "not_requested",
  items = [],
  subtotal = 0,
  tax = 0,
  total = 0,
  onRequestBill,
  onPayBill,
  isRequesting = false,
  isPaying = false,
}: BillViewProps) {
  if (status === "not_requested") {
    return (
      <div className="mx-auto flex min-h-[60vh] max-w-2xl flex-col items-center justify-center px-6 text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="flex h-24 w-24 items-center justify-center rounded-full bg-cyan-500/10 ring-1 ring-cyan-400/20"
        >
          <Receipt size={44} className="text-cyan-400" />
        </motion.div>

        <h2 className="mt-7 text-2xl font-bold text-white">
          Ready for your bill?
        </h2>

        <p className="mt-3 max-w-md text-white/50">
          Once you are finished dining, request your bill and our staff will
          prepare it for you.
        </p>

        <button
          type="button"
          disabled={isRequesting}
          onClick={onRequestBill}
          className="mt-8 flex items-center justify-center gap-3 rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-600 px-8 py-4 font-semibold text-white shadow-lg shadow-cyan-500/10 transition hover:from-cyan-400 hover:to-blue-500 disabled:cursor-not-allowed disabled:opacity-50"
        >
          {isRequesting ? (
            <>
              <span className="h-5 w-5 animate-spin rounded-full border-2 border-white/30 border-t-white" />
              Requesting...
            </>
          ) : (
            <>
              <Receipt size={20} />
              Request Bill
            </>
          )}
        </button>
      </div>
    );
  }

  if (status === "requested") {
    return (
      <div className="mx-auto flex min-h-[60vh] max-w-2xl flex-col items-center justify-center px-6 text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          className="flex h-24 w-24 items-center justify-center rounded-full bg-amber-500/10 ring-1 ring-amber-400/20"
        >
          <Clock3 size={44} className="text-amber-400" />
        </motion.div>

        <h2 className="mt-7 text-2xl font-bold text-white">Bill requested</h2>

        <p className="mt-3 max-w-md text-white/50">
          Your waiter has been notified. Please wait while your bill is
          prepared.
        </p>

        <div className="mt-8 rounded-2xl border border-amber-400/10 bg-amber-400/5 px-6 py-4 text-sm text-amber-300">
          Your bill is being prepared.
        </div>
      </div>
    );
  }

  const isPaid = status === "paid";

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div className="flex items-center gap-3">
        <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-cyan-500/10">
          <Receipt size={24} className="text-cyan-400" />
        </div>

        <div>
          <h2 className="text-2xl font-bold text-white">Your Bill</h2>
          <p className="text-sm text-white/50">Thank you for dining with us.</p>
        </div>
      </div>

      <div
        className={
          isPaid
            ? "flex items-center gap-3 rounded-2xl border border-green-500/20 bg-green-500/10 p-4 text-green-400"
            : "flex items-center gap-3 rounded-2xl border border-cyan-500/20 bg-cyan-500/10 p-4 text-cyan-400"
        }
      >
        {isPaid ? <CheckCircle2 size={22} /> : <CreditCard size={22} />}

        <div>
          <p className="font-semibold">
            {isPaid ? "Payment completed" : "Bill is ready"}
          </p>

          <p className="mt-0.5 text-sm opacity-70">
            {isPaid
              ? "Thank you for dining with us."
              : "Please review your bill below."}
          </p>
        </div>
      </div>

      <div className="rounded-3xl border border-white/10 bg-white/5 p-6 backdrop-blur-xl">
        <h3 className="mb-5 text-lg font-semibold text-white">Order Summary</h3>

        {items.length > 0 ? (
          <div className="space-y-4">
            {items.map((item) => (
              <div
                key={item.id}
                className="flex items-center justify-between gap-4 border-b border-white/5 pb-4 last:border-0 last:pb-0"
              >
                <div>
                  <p className="font-medium text-white">{item.name}</p>
                  <p className="mt-1 text-sm text-white/40">
                    {item.quantity} × ₹{item.price.toFixed(2)}
                  </p>
                </div>

                <p className="font-semibold text-white">
                  ₹{(item.price * item.quantity).toFixed(2)}
                </p>
              </div>
            ))}
          </div>
        ) : (
          <div className="py-6 text-center text-white/40">
            No bill items available yet.
          </div>
        )}
      </div>

      <div className="rounded-3xl border border-white/10 bg-white/5 p-6 backdrop-blur-xl">
        <div className="space-y-3">
          <div className="flex justify-between text-sm">
            <span className="text-white/50">Subtotal</span>
            <span className="text-white">₹{subtotal.toFixed(2)}</span>
          </div>

          <div className="flex justify-between text-sm">
            <span className="text-white/50">Tax</span>
            <span className="text-white">₹{tax.toFixed(2)}</span>
          </div>

          <div className="border-t border-white/10 pt-4">
            <div className="flex items-center justify-between">
              <span className="text-lg font-semibold text-white">Total</span>

              <span className="text-2xl font-bold text-cyan-400">
                ₹{total.toFixed(2)}
              </span>
            </div>
          </div>
        </div>
      </div>

      {status === "ready" && (
        <button
          type="button"
          disabled={isPaying}
          onClick={onPayBill}
          className="flex w-full items-center justify-center gap-3 rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-600 py-4 text-lg font-semibold text-white shadow-lg shadow-cyan-500/10 transition hover:from-cyan-400 hover:to-blue-500 disabled:cursor-not-allowed disabled:opacity-50"
        >
          {isPaying ? (
            <>
              <span className="h-5 w-5 animate-spin rounded-full border-2 border-white/30 border-t-white" />
              Processing...
            </>
          ) : (
            <>
              <CreditCard size={21} />
              Pay Bill
            </>
          )}
        </button>
      )}
    </div>
  );
}
