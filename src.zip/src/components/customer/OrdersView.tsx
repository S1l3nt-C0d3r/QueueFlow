import { Clock3 } from "lucide-react";
import { motion } from "motion/react";

export default function OrdersView() {

const orders=[];

if(!orders.length){

return(

        <div
            className="
            rounded-3xl
            border
            border-dashed
            border-white/10
            py-24
            text-center
        ">

        <Clock3
            className="
            mx-auto
            mb-5
            text-white/30
            "
            size={56}
        />

        <h2
        className="
        text-2xl
        font-semibold
        text-white
        "
        >

        No Orders Yet

        </h2>

        <p
        className="
        mt-3
        text-white/50
        "
        >

        Your placed orders will
        appear here.

        </p>

        </div>

        );

        }
        }