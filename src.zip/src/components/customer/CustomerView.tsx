import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  UtensilsCrossed,
  ShoppingCart,
  Receipt,
  PackageCheck,
} from "lucide-react";

import SessionHeader from "./SessionHeader";
import OrdersView from "./OrdersView";
import MenuGrid from "./MenuGrid";
import CartView, { CartItem } from "./CartView";
import BillView from "./BillView";
import { MenuResponse } from "../../types/menu";

type Tab = "order" | "cart" | "orders" | "bill";

export default function CustomerView() {
  const [activeTab, setActiveTab] = useState<Tab>("order");

  /*
   * Cart is owned by CustomerView.
   *
   * This is the single source of truth
   * for the entire customer experience.
   */
  const [cart, setCart] = useState<CartItem[]>([]);

  /*
   * Orders will be connected to the
   * existing order service shortly.
   *
   * Keeping this here means OrdersView
   * will eventually receive the same
   * session-level data without owning
   * API state itself.
   */
  const [orders] = useState<unknown[]>([]);

  /*
   * Return the current quantity of a
   * menu item in the cart.
   */
  const getQuantity = (menuItemId: string): number => {
    return (
      cart.find((cartItem) => cartItem.item.id === menuItemId)?.quantity ?? 0
    );
  };

  /*
   * Add an item to the cart.
   */
  const handleAdd = (menuItem: MenuResponse) => {
    setCart((currentCart) => {
      const existingItem = currentCart.find(
        (cartItem) => cartItem.item.id === menuItem.id,
      );

      if (existingItem) {
        return currentCart.map((cartItem) =>
          cartItem.item.id === menuItem.id
            ? {
                ...cartItem,
                quantity: cartItem.quantity + 1,
              }
            : cartItem,
        );
      }

      return [
        ...currentCart,
        {
          item: menuItem,
          quantity: 1,
        },
      ];
    });
  };

  /*
   * Increase quantity.
   */
  const handleIncrease = (menuItem: MenuResponse) => {
    setCart((currentCart) =>
      currentCart.map((cartItem) =>
        cartItem.item.id === menuItem.id
          ? {
              ...cartItem,
              quantity: cartItem.quantity + 1,
            }
          : cartItem,
      ),
    );
  };

  /*
   * Decrease quantity.
   *
   * If quantity reaches zero,
   * remove the item completely.
   */
  const handleDecrease = (menuItem: MenuResponse) => {
    setCart((currentCart) =>
      currentCart
        .map((cartItem) =>
          cartItem.item.id === menuItem.id
            ? {
                ...cartItem,
                quantity: cartItem.quantity - 1,
              }
            : cartItem,
        )
        .filter((cartItem) => cartItem.quantity > 0),
    );
  };

  /*
   * Total number of individual items
   * currently in the cart.
   *
   * Example:
   *
   * Burger × 2
   * Coke × 1
   *
   * cartCount = 3
   */
  const cartCount = cart.reduce(
    (total, cartItem) => total + cartItem.quantity,
    0,
  );

  /*
   * Remove an item completely.
   */
  const handleRemoveItem = (menuItem: MenuResponse) => {
    setCart((currentCart) =>
      currentCart.filter((cartItem) => cartItem.item.id !== menuItem.id),
    );
  };

  /*
   * Place order will be connected to
   * orderService once we wire the exact
   * backend request contract.
   *
   * For now we simply keep the cart.
   */
  const handlePlaceOrder = () => {
    console.log("Place order:", cart);
  };

  return (
    <div
      className="
      min-h-screen
      bg-gradient-to-br
      from-slate-950
      via-blue-950
      to-slate-950
      text-white
    "
    >
      {/* Session Header */}

      <SessionHeader
        restaurantName="Bella Italia"
        tableNumber={7}
        partySize={4}
        sessionTime="18 mins"
      />

      {/* Main Content */}

      <main
        className="
        mx-auto
        max-w-7xl
        px-4
        pb-28
        pt-6
      "
      >
        <AnimatePresence mode="wait">
          {/* ORDER */}

          {activeTab === "order" && (
            <motion.div
              key="order"
              initial={{
                opacity: 0,
                y: 15,
              }}
              animate={{
                opacity: 1,
                y: 0,
              }}
              exit={{
                opacity: 0,
                y: -15,
              }}
            >
              <MenuGrid
                getQuantity={getQuantity}
                onAdd={handleAdd}
                onIncrease={handleIncrease}
                onDecrease={handleDecrease}
              />
            </motion.div>
          )}

          {/* CART */}

          {activeTab === "cart" && (
            <motion.div
              key="cart"
              initial={{
                opacity: 0,
                y: 15,
              }}
              animate={{
                opacity: 1,
                y: 0,
              }}
              exit={{
                opacity: 0,
                y: -15,
              }}
            >
              <CartView
                items={cart}
                onIncrease={handleIncrease}
                onRemove={handleRemoveItem}
                onDecrease={handleDecrease}
                onPlaceOrder={handlePlaceOrder}
              />
            </motion.div>
          )}

          {/* ORDERS */}

          {activeTab === "orders" && (
            <motion.div
              key="orders"
              initial={{
                opacity: 0,
                y: 15,
              }}
              animate={{
                opacity: 1,
                y: 0,
              }}
              exit={{
                opacity: 0,
                y: -15,
              }}
            >
              <OrdersView />
            </motion.div>
          )}

          {/* BILL */}

          {activeTab === "bill" && (
            <motion.div
              key="bill"
              initial={{
                opacity: 0,
                y: 15,
              }}
              animate={{
                opacity: 1,
                y: 0,
              }}
              exit={{
                opacity: 0,
                y: -15,
              }}
            >
              <BillView />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Bottom Navigation */}

      <div
        className="
        fixed
        bottom-0
        left-0
        right-0
        z-50
        border-t
        border-white/10
        bg-slate-950/95
        backdrop-blur-xl
      "
      >
        <div
          className="
          mx-auto
          flex
          max-w-4xl
          justify-around
          py-3
        "
        >
          {/* Order */}

          <button
            onClick={() => setActiveTab("order")}
            className={`

              flex
              flex-col
              items-center
              gap-1
              transition

              ${activeTab === "order" ? "text-cyan-400" : "text-white/50"}

            `}
          >
            <UtensilsCrossed size={22} />

            <span className="text-xs">Order</span>
          </button>

          {/* Cart */}

          <button
            onClick={() => setActiveTab("cart")}
            className={`

              relative
              flex
              flex-col
              items-center
              gap-1
              transition

              ${activeTab === "cart" ? "text-cyan-400" : "text-white/50"}

            `}
          >
            <ShoppingCart size={22} />

            {cartCount > 0 && (
              <span
                className="
                absolute
                -right-2
                -top-1
                flex
                h-5
                w-5
                items-center
                justify-center
                rounded-full
                bg-red-500
                text-[10px]
                font-bold
                text-white
              "
              >
                {cartCount}
              </span>
            )}

            <span className="text-xs">Cart</span>
          </button>

          {/* Orders */}

          <button
            onClick={() => setActiveTab("orders")}
            className={`

              flex
              flex-col
              items-center
              gap-1
              transition

              ${activeTab === "orders" ? "text-cyan-400" : "text-white/50"}

            `}
          >
            <PackageCheck size={22} />

            <span className="text-xs">Orders</span>
          </button>

          {/* Bill */}

          <button
            onClick={() => setActiveTab("bill")}
            className={`

              flex
              flex-col
              items-center
              gap-1
              transition

              ${activeTab === "bill" ? "text-cyan-400" : "text-white/50"}

            `}
          >
            <Receipt size={22} />

            <span className="text-xs">Bill</span>
          </button>
        </div>
      </div>
    </div>
  );
}
