import { api } from "./api";

import { CustomerOrder, CreateOrderRequest, OrderItem } from "../types/orders";

export const orderService = {
  getAll() {
    return api.get<CustomerOrder[]>("/orders");
  },

  getById(orderId: string) {
    return api.get<CustomerOrder>(`/orders/${orderId}`);
  },

  create(request: CreateOrderRequest) {
    return api.post<CustomerOrder>("/orders", request);
  },

  getItems(orderId: string) {
    return api.get<OrderItem[]>(`/orders/${orderId}/items`);
  },

  addItem(orderId: string, item: OrderItem) {
    return api.post<CustomerOrder>(`/orders/${orderId}/items`, item);
  },

  removeItem(orderId: string, itemId: string) {
    return api.delete<CustomerOrder>(`/orders/${orderId}/items/${itemId}`);
  },
};
