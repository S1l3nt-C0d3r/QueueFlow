import dotenv from "dotenv";

dotenv.config();

export const env = {
    PORT: Number(process.env.PORT) || 5000,

    JWT_SECRET: process.env.JWT_SECRET || "development",

    NODE_ENV: process.env.NODE_ENV || "development",
};